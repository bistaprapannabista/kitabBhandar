from django.db import models
# Create your models here.


class Books_category(models.Model):
    category_name = models.CharField(max_length=50)

    def __str__(self):
        return self.category_name

class Sub_category(models.Model):
    category_name = models.CharField(max_length=50)
    book_category = models.ForeignKey(Books_category,on_delete = models.CASCADE)

    def __str__(self):
        return self.category_name

class Book(models.Model):
    book_name = models.CharField(max_length=50)
    writer_name = models.CharField(max_length=50)
    sub_category = models.ForeignKey(Sub_category,on_delete=models.CASCADE)
    books_category = models.ForeignKey(Books_category,on_delete=models.CASCADE)
    download_link = models.CharField(max_length=1000)
    date = models.DateTimeField(auto_now_add=True)
    

    def __str__(self):
        return self.book_name + " by " + self.writer_name



class Contact(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    email = models.EmailField(max_length=50)
    phone = models.CharField(max_length=15)
    message = models.TextField()
    date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        if(len(self.message) < 15):
            return ' " ' + self.message[:15] + ' " ' + " by " + self.first_name + " " + self.last_name

        else:
            return ' " ' + self.message[:15] + '..." by ' + self.first_name + " " + self.last_name
