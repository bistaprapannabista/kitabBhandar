from django.shortcuts import render, redirect
from django.http import HttpResponse
from home.models import *
from django.contrib import messages
import datetime


# Create your views here.


def home(request):
    books_category = Books_category.objects.all().order_by('-category_name').reverse()
    return render(request, 'index.html', {'books_category': books_category})


def sub_category(request, category_name):
    category = Books_category.objects.get(category_name=category_name)
    sub_category = Sub_category.objects.filter(book_category = category).order_by('-category_name').reverse()
    return render(request, 'subCategory.html', {'category': category,'sub_categories':sub_category})

def book(request, category_name , sub_category_name):
    category_name_obj = Books_category.objects.get(category_name=category_name)
    sub_category_name_obj = Sub_category.objects.get(category_name=sub_category_name)
    books_list = Book.objects.filter(books_category=category_name_obj, sub_category=sub_category_name_obj).order_by('-book_name').reverse()
    return render(request, 'books.html',{'books_list':books_list})

def contact(request):
    if request.method == "POST":
          first_name = request.POST["first_name"]
          last_name = request.POST["last_name"]
          email = request.POST["email"]
          phone = request.POST["phone"] 
          message = request.POST["message"]
          obj = Contact(first_name=first_name, last_name=last_name, email=email, phone=phone, message=message)
          obj.save()
          messages.success(request, 'Your message has been send successfully.')
          return redirect('/')
    return render(request, 'contact.html')

def search(request):
    if request.method == "GET":
        query = request.GET["query"]
        if len(query)>40 or len(query)<3:
            messages.info(request,"Search input is either too short or long.")
            return redirect('/')
        else:
            books_by_name = Book.objects.filter(book_name__icontains=query)
            books_by_writer = Book.objects.filter(writer_name__icontains=query)
            results = books_by_name.union(books_by_writer)
    return render(request, 'search.html',{'results':results,'query':query})

def about(request):
    return render(request,"about.html")
    
def login(request):
    return render(request,"commingSoon.html")
